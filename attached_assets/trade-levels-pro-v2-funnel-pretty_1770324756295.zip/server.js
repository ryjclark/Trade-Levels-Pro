require('dotenv').config();

const path = require('path');
const express = require('express');
const session = require('express-session');

const {
  getPlanById,
  getPlanByDateSymbol,
  listPlans,
  listPublishedPlans,
  upsertPlan,
  insertPublishLog,
  listPublishLogs,
  getSettings,
  setSetting
} = require('./db');
const { formatAll } = require('./formatter');
const { sendTelegramMessage } = require('./telegram');

const app = express();
const PORT = process.env.PORT || 3000;

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-me';

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 }
  })
);

function todayISO() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.redirect('/admin/login');
}

function parseNumber(value) {
  if (value === '' || value === null || value === undefined) return null;
  const num = Number(value);
  return Number.isNaN(num) ? NaN : num;
}

function buildPlanFromBody(body) {
  return {
    id: body.id ? Number(body.id) : undefined,
    date: body.date,
    symbol: body.symbol,
    contract: body.contract || null,
    tier: body.tier || 'pro',
    dynamic_zone_top: parseNumber(body.dynamic_zone_top),
    dynamic_zone_bottom: parseNumber(body.dynamic_zone_bottom),
    magnet: parseNumber(body.magnet),
    r1: parseNumber(body.r1),
    r2: parseNumber(body.r2),
    r3: parseNumber(body.r3),
    r4: parseNumber(body.r4),
    s1: parseNumber(body.s1),
    s2: parseNumber(body.s2),
    s3: parseNumber(body.s3),
    s4: parseNumber(body.s4),
    bias: body.bias || '',
    setup_1: body.setup_1 || '',
    setup_2: body.setup_2 || '',
    notes: body.notes || null
  };
}

function validatePlan(plan, { requireAll }) {
  const errors = [];
  const requiredFields = [
    'date',
    'symbol',
    'dynamic_zone_top',
    'dynamic_zone_bottom',
    'magnet',
    'r1',
    'r2',
    'r3',
    'r4',
    's1',
    's2',
    's3',
    's4',
    'bias',
    'setup_1',
    'setup_2'
  ];

  if (requireAll) {
    requiredFields.forEach((field) => {
      if (plan[field] === null || plan[field] === undefined || plan[field] === '') {
        errors.push(`Missing required field: ${field}`);
      }
    });
  }

  const numericFields = [
    'dynamic_zone_top',
    'dynamic_zone_bottom',
    'magnet',
    'r1',
    'r2',
    'r3',
    'r4',
    's1',
    's2',
    's3',
    's4'
  ];

  numericFields.forEach((field) => {
    if (plan[field] !== null && plan[field] !== undefined && Number.isNaN(Number(plan[field]))) {
      errors.push(`Field ${field} must be a number.`);
    }
  });

  const dzTop = Number(plan.dynamic_zone_top);
  const dzBottom = Number(plan.dynamic_zone_bottom);
  if (Number.isFinite(dzTop) && Number.isFinite(dzBottom) && dzTop <= dzBottom) {
    errors.push('Dynamic Zone Top must be greater than Dynamic Zone Bottom.');
  }

  return errors;
}

function validatePublishGuardrails(plan) {
  const errors = [];
  if (plan.magnet === null || plan.magnet === undefined || Number.isNaN(Number(plan.magnet))) {
    errors.push('Magnet is required for publishing.');
  }
  if (
    plan.dynamic_zone_top === null ||
    plan.dynamic_zone_bottom === null ||
    plan.dynamic_zone_top === undefined ||
    plan.dynamic_zone_bottom === undefined ||
    Number.isNaN(Number(plan.dynamic_zone_top)) ||
    Number.isNaN(Number(plan.dynamic_zone_bottom))
  ) {
    errors.push('Dynamic Zone Top and Bottom are required for publishing.');
  }
  return errors;
}

const SETTINGS_KEYS = ['JOIN_URL', 'SUBSTACK_URL', 'X_URL', 'PRICE_TEXT', 'FOOTER_TEXT', 'TELEGRAM_FOOTER_ENABLED'];

function loadSettings() {
  const values = getSettings(SETTINGS_KEYS);
  return {
    joinUrl: values.JOIN_URL || '',
    substackUrl: values.SUBSTACK_URL || '',
    xUrl: values.X_URL || '',
    priceText: values.PRICE_TEXT || '',
    footerText: values.FOOTER_TEXT || '',
    footerEnabled: values.TELEGRAM_FOOTER_ENABLED === 'on'
  };
}

function buildFooterLine(settings) {
  if (!settings.footerEnabled) return null;
  if (!settings.joinUrl) return null;
  const template = settings.footerText && settings.footerText.trim().length > 0
    ? settings.footerText.trim()
    : `Join: ${settings.joinUrl}`;
  return template.replace('{JOIN_URL}', settings.joinUrl);
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.get('/', (req, res) => {
  const settings = loadSettings();
  const priceText = settings.priceText || 'Pricing details available on the join page.';
  return res.render('public_home', {
    joinUrl: settings.joinUrl,
    substackUrl: settings.substackUrl,
    xUrl: settings.xUrl,
    priceText
  });
});

app.get('/pricing', (req, res) => {
  const settings = loadSettings();
  const priceText = settings.priceText || 'Pricing details available on the join page.';
  return res.render('public_pricing', {
    joinUrl: settings.joinUrl,
    priceText
  });
});

app.get('/about', (req, res) => {
  return res.render('public_about');
});

app.get('/trackrecord', (req, res) => {
  const settings = loadSettings();
  const plans = listPublishedPlans(300);
  return res.render('public_trackrecord', {
    joinUrl: settings.joinUrl,
    plans
  });
});

app.get('/admin/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/admin/login', (req, res) => {
  if (!ADMIN_PASSWORD) {
    return res.render('login', { error: 'ADMIN_PASSWORD is not set.' });
  }

  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    req.session.isAdmin = true;
    return res.redirect('/admin');
  }

  return res.render('login', { error: 'Invalid password.' });
});

app.post('/admin/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
});

app.get('/admin', requireAdmin, (req, res) => {
  const date = req.query.date || todayISO();
  const symbol = req.query.symbol || 'ES';
  const plan = getPlanByDateSymbol(date, symbol);
  const settings = loadSettings();

  let outputs = null;
  if (plan) {
    try {
      outputs = formatAll(plan);
    } catch (err) {
      outputs = null;
    }
  }

  let success = null;
  let errors = [];
  let warnings = [];
  if (req.query.test === 'success') {
    success = 'Test Telegram message sent.';
  }
  if (req.query.test === 'error') {
    errors.push(`Test Telegram failed: ${req.query.message || 'Unknown error'}`);
  }
  if (settings.footerEnabled && !settings.joinUrl) {
    warnings.push('Footer is enabled but JOIN_URL is blank. Footer will not be appended.');
  }

  res.render('admin', {
    plan: plan || {
      date,
      symbol,
      status: 'draft',
      tier: 'pro'
    },
    outputs,
    errors,
    warnings,
    success,
    settings
  });
});

app.post('/admin/save', requireAdmin, async (req, res) => {
  const action = req.body.action || 'save';
  const planInput = buildPlanFromBody(req.body);
  const settings = loadSettings();

  const requireAll = action === 'publish_pro';
  const errors = validatePlan(planInput, { requireAll });
  const publishGuardrails = action.startsWith('publish_') ? validatePublishGuardrails(planInput) : [];
  errors.push(...publishGuardrails);
  const warnings = [];
  if (settings.footerEnabled && !settings.joinUrl) {
    warnings.push('Footer is enabled but JOIN_URL is blank. Footer will not be appended.');
  }

  if (errors.length) {
    return res.render('admin', {
      plan: { ...planInput, status: action === 'publish' ? 'draft' : 'draft' },
      outputs: formatAll(planInput),
      errors,
      warnings,
      success: null,
      settings
    });
  }

  let status = 'draft';
  let published_at = null;
  let telegram_message_id = null;
  let telegram_message = null;
  let telegram_message_variant = null;

  if (action === 'publish_free' || action === 'publish_pro') {
    const preview = formatAll(planInput);
    const isPro = action === 'publish_pro';
    telegram_message_variant = isPro ? 'pro' : 'free';
    telegram_message = isPro ? preview.telegramPro : preview.telegramFree;
    const footerLine = buildFooterLine(settings);
    if (footerLine) {
      telegram_message = `${telegram_message}\n\n${footerLine}`;
    }

    try {
      const token = process.env.TELEGRAM_BOT_TOKEN;
      const chatId = process.env.TELEGRAM_CHAT_ID;
      if (!token || !chatId) {
        throw new Error('TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID is not set.');
      }

      const response = await sendTelegramMessage({
        token,
        chatId,
        text: telegram_message
      });

      telegram_message_id = response.result?.message_id
        ? String(response.result.message_id)
        : null;
      status = 'published';
      published_at = new Date().toISOString();

      const savedPlan = upsertPlan({
        ...planInput,
        status,
        published_at,
        telegram_message_id,
        telegram_message,
        telegram_message_variant
      });

      insertPublishLog({
        plan_id: savedPlan.id,
        destination: 'telegram',
        variant: telegram_message_variant,
        status: 'success',
        response_payload: JSON.stringify(response)
      });

      return res.render('admin', {
        plan: savedPlan,
        outputs: formatAll(savedPlan),
        errors: [],
        warnings,
        success: `Published ${telegram_message_variant.toUpperCase()} to Telegram successfully.`,
        settings
      });
    } catch (error) {
      const savedPlan = upsertPlan({
        ...planInput,
        status: 'draft'
      });

      insertPublishLog({
        plan_id: savedPlan.id,
        destination: 'telegram',
        variant: telegram_message_variant || null,
        status: 'error',
        error_message: error.message,
        response_payload: error.payload ? JSON.stringify(error.payload) : null
      });

      return res.render('admin', {
        plan: savedPlan,
        outputs: formatAll(savedPlan),
        errors: [`Publish failed: ${error.message}`],
        warnings,
        success: null,
        settings
      });
    }
  }

  const savedPlan = upsertPlan({
    ...planInput,
    status,
    published_at,
    telegram_message_id,
    telegram_message,
    telegram_message_variant
  });

  const outputs = formatAll(savedPlan);

  return res.render('admin', {
    plan: savedPlan,
    outputs,
    errors: [],
    warnings,
    success: 'Draft saved.',
    settings
  });
});

app.post('/admin/test-telegram', requireAdmin, async (req, res) => {
  try {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!token || !chatId) {
      throw new Error('TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID is not set.');
    }

    await sendTelegramMessage({
      token,
      chatId,
      text: '✅ Trade Levels Pro test message'
    });

    return res.redirect('/admin?test=success');
  } catch (error) {
    return res.redirect(`/admin?test=error&message=${encodeURIComponent(error.message)}`);
  }
});

app.get('/admin/archive', requireAdmin, (req, res) => {
  const plans = listPlans(200);
  res.render('archive', { plans });
});

app.get('/admin/archive/:id', requireAdmin, (req, res) => {
  const planId = Number(req.params.id);
  const plan = getPlanById(planId);
  if (!plan) {
    return res.status(404).send('Plan not found');
  }

  const outputs = formatAll(plan);
  const logs = listPublishLogs(planId);

  return res.render('archive_detail', { plan, outputs, logs });
});

app.get('/admin/settings', requireAdmin, (req, res) => {
  const settings = loadSettings();
  res.render('admin_settings', { settings, success: null, errors: [] });
});

app.post('/admin/settings', requireAdmin, (req, res) => {
  const payload = {
    JOIN_URL: (req.body.join_url || '').trim(),
    SUBSTACK_URL: (req.body.substack_url || '').trim(),
    X_URL: (req.body.x_url || '').trim(),
    PRICE_TEXT: (req.body.price_text || '').trim(),
    FOOTER_TEXT: (req.body.footer_text || '').trim(),
    TELEGRAM_FOOTER_ENABLED: req.body.footer_enabled === 'on' ? 'on' : 'off'
  };

  Object.entries(payload).forEach(([key, value]) => {
    setSetting(key, value);
  });

  const settings = loadSettings();
  const errors = [];
  const success = 'Settings saved.';
  return res.render('admin_settings', { settings, success, errors });
});

app.listen(PORT, () => {
  console.log(`Trade Levels Pro running on port ${PORT}`);
});
