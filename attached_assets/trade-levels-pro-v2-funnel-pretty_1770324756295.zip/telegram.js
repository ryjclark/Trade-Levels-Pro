async function sendTelegramMessage({ token, chatId, text }) {
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text
    })
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok || !payload.ok) {
    const errorMessage = payload.description || `Telegram API error (status ${response.status})`;
    const error = new Error(errorMessage);
    error.payload = payload;
    throw error;
  }

  return payload;
}

module.exports = {
  sendTelegramMessage
};
