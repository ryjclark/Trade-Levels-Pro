const path = require('path');
const Database = require('better-sqlite3');

const dbPath = process.env.DB_PATH || path.join(__dirname, 'data', 'trade_levels.sqlite');
const db = new Database(dbPath);

db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  symbol TEXT NOT NULL,
  contract TEXT,
  dynamic_zone_top REAL,
  dynamic_zone_bottom REAL,
  magnet REAL,
  r1 REAL,
  r2 REAL,
  r3 REAL,
  r4 REAL,
  s1 REAL,
  s2 REAL,
  s3 REAL,
  s4 REAL,
  bias TEXT,
  setup_1 TEXT,
  setup_2 TEXT,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  published_at TEXT,
  telegram_message_id TEXT,
  telegram_message TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(date, symbol)
);

CREATE TABLE IF NOT EXISTS publish_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id INTEGER NOT NULL,
  attempt_time TEXT NOT NULL,
  destination TEXT NOT NULL,
  status TEXT NOT NULL,
  error_message TEXT,
  response_payload TEXT,
  FOREIGN KEY(plan_id) REFERENCES plans(id)
);
`);

function nowIso() {
  return new Date().toISOString();
}

function getPlanById(id) {
  return db.prepare('SELECT * FROM plans WHERE id = ?').get(id);
}

function getPlanByDateSymbol(date, symbol) {
  return db.prepare('SELECT * FROM plans WHERE date = ? AND symbol = ?').get(date, symbol);
}

function listPlans(limit = 100) {
  return db.prepare('SELECT * FROM plans ORDER BY date DESC, symbol ASC LIMIT ?').all(limit);
}

function upsertPlan(data) {
  const existing = data.id
    ? getPlanById(data.id)
    : getPlanByDateSymbol(data.date, data.symbol);

  const payload = {
    date: data.date,
    symbol: data.symbol,
    contract: data.contract || null,
    dynamic_zone_top: data.dynamic_zone_top,
    dynamic_zone_bottom: data.dynamic_zone_bottom,
    magnet: data.magnet,
    r1: data.r1,
    r2: data.r2,
    r3: data.r3,
    r4: data.r4,
    s1: data.s1,
    s2: data.s2,
    s3: data.s3,
    s4: data.s4,
    bias: data.bias,
    setup_1: data.setup_1,
    setup_2: data.setup_2,
    notes: data.notes || null,
    status: data.status || 'draft',
    published_at: data.published_at || null,
    telegram_message_id: data.telegram_message_id || null,
    telegram_message: data.telegram_message || null,
    updated_at: nowIso()
  };

  if (existing) {
    db.prepare(`
      UPDATE plans SET
        date=@date,
        symbol=@symbol,
        contract=@contract,
        dynamic_zone_top=@dynamic_zone_top,
        dynamic_zone_bottom=@dynamic_zone_bottom,
        magnet=@magnet,
        r1=@r1,
        r2=@r2,
        r3=@r3,
        r4=@r4,
        s1=@s1,
        s2=@s2,
        s3=@s3,
        s4=@s4,
        bias=@bias,
        setup_1=@setup_1,
        setup_2=@setup_2,
        notes=@notes,
        status=@status,
        published_at=@published_at,
        telegram_message_id=@telegram_message_id,
        telegram_message=@telegram_message,
        updated_at=@updated_at
      WHERE id = @id
    `).run({ ...payload, id: existing.id });

    return getPlanById(existing.id);
  }

  const createdAt = nowIso();
  const result = db.prepare(`
    INSERT INTO plans (
      date, symbol, contract, dynamic_zone_top, dynamic_zone_bottom, magnet,
      r1, r2, r3, r4, s1, s2, s3, s4, bias, setup_1, setup_2, notes,
      status, published_at, telegram_message_id, telegram_message, created_at, updated_at
    ) VALUES (
      @date, @symbol, @contract, @dynamic_zone_top, @dynamic_zone_bottom, @magnet,
      @r1, @r2, @r3, @r4, @s1, @s2, @s3, @s4, @bias, @setup_1, @setup_2, @notes,
      @status, @published_at, @telegram_message_id, @telegram_message, @created_at, @updated_at
    )
  `).run({ ...payload, created_at: createdAt, updated_at: createdAt });

  return getPlanById(result.lastInsertRowid);
}

function insertPublishLog({ plan_id, destination, status, error_message, response_payload }) {
  db.prepare(`
    INSERT INTO publish_logs (plan_id, attempt_time, destination, status, error_message, response_payload)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    plan_id,
    nowIso(),
    destination,
    status,
    error_message || null,
    response_payload || null
  );
}

function listPublishLogs(planId) {
  return db.prepare('SELECT * FROM publish_logs WHERE plan_id = ? ORDER BY attempt_time DESC').all(planId);
}

module.exports = {
  getPlanById,
  getPlanByDateSymbol,
  listPlans,
  upsertPlan,
  insertPublishLog,
  listPublishLogs
};
