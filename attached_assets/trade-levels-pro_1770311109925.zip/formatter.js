function formatNumber(value) {
  if (value === null || value === undefined) return '';
  const num = Number(value);
  if (Number.isNaN(num)) return '';
  return num.toString();
}

function formatDateTitle(dateStr) {
  const date = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
}

function formatTitle(plan) {
  const datePart = formatDateTitle(plan.date);
  const contract = plan.contract ? ` (${plan.contract})` : '';
  return `${plan.symbol} Daily Trade Plan — ${datePart}${contract}`;
}

function formatTelegram(plan) {
  const title = formatTitle(plan);
  const lines = [
    title,
    '',
    `Magnet: ${formatNumber(plan.magnet)}`,
    `Dynamic Zone: ${formatNumber(plan.dynamic_zone_bottom)} – ${formatNumber(plan.dynamic_zone_top)}`,
    `Resistance: R1 ${formatNumber(plan.r1)} | R2 ${formatNumber(plan.r2)} | R3 ${formatNumber(plan.r3)} | R4 ${formatNumber(plan.r4)}`,
    `Support: S1 ${formatNumber(plan.s1)} | S2 ${formatNumber(plan.s2)} | S3 ${formatNumber(plan.s3)} | S4 ${formatNumber(plan.s4)}`,
    `Bias: ${plan.bias}`,
    'Best Setups:',
    `- ${plan.setup_1}`,
    `- ${plan.setup_2}`
  ];

  if (plan.notes) {
    lines.push('', `Notes: ${plan.notes}`);
  }

  lines.push('', 'Trade Smarter. React to Price. No Predictions.');
  return lines.join('\n');
}

function formatSubstack(plan) {
  const title = formatTitle(plan);
  const lines = [
    `# ${title}`,
    '',
    `**Magnet:** ${formatNumber(plan.magnet)}`,
    `**Dynamic Zone:** ${formatNumber(plan.dynamic_zone_bottom)} – ${formatNumber(plan.dynamic_zone_top)}`,
    `**Resistance:** R1 ${formatNumber(plan.r1)} | R2 ${formatNumber(plan.r2)} | R3 ${formatNumber(plan.r3)} | R4 ${formatNumber(plan.r4)}`,
    `**Support:** S1 ${formatNumber(plan.s1)} | S2 ${formatNumber(plan.s2)} | S3 ${formatNumber(plan.s3)} | S4 ${formatNumber(plan.s4)}`,
    `**Bias:** ${plan.bias}`,
    '',
    '**Best Setups:**',
    `- ${plan.setup_1}`,
    `- ${plan.setup_2}`
  ];

  if (plan.notes) {
    lines.push('', `**Notes:** ${plan.notes}`);
  }

  lines.push('', 'Trade Smarter. React to Price. No Predictions.');
  return lines.join('\n');
}

function formatAll(plan) {
  return {
    title: formatTitle(plan),
    telegram: formatTelegram(plan),
    substack: formatSubstack(plan)
  };
}

module.exports = {
  formatAll,
  formatTelegram,
  formatSubstack,
  formatTitle
};
