# Trade Levels Pro

Daily ES/NQ “Dynamic Zone + Magnet + S/R” trade plan system.

## What’s Included (V1)
- Password-protected Admin area
- Daily plan entry with draft + publish flow
- Deterministic formatter for Telegram + Substack
- Telegram auto-publish with logs
- Archive + detail views
- Health check endpoint

## Tech Stack
- Node.js + Express
- SQLite (better-sqlite3)
- EJS server-rendered views

## Local / Replit Setup
1. Install dependencies: `npm install`
2. Create `.env` (use `.env.example` as reference)
3. Run: `npm run dev`
4. Visit `/admin` and log in

## Required Environment Variables
- `ADMIN_PASSWORD`
- `SESSION_SECRET`
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

## Health Check
- `GET /health` returns `{ "status": "ok" }`

## Archive
- `/admin/archive` lists all saved plans

For full setup and troubleshooting, see `RUNBOOK.md`.
