# Trade Levels Pro Runbook (V1)

## Quick Start (Replit)
1. Create a new Replit Node.js project.
2. Import this repo into Replit.
3. In Replit, open **Secrets** and add the environment variables listed below.
4. Open the Shell and run `npm install`.
5. Start the app: `npm run dev`.
6. Open the app URL and go to `/admin`.

## Required Environment Variables
- `ADMIN_PASSWORD` — password for Admin login
- `SESSION_SECRET` — random string for session cookies
- `TELEGRAM_BOT_TOKEN` — Telegram bot token from BotFather
- `TELEGRAM_CHAT_ID` — your Telegram channel chat ID
- `DB_PATH` (optional) — defaults to `./data/trade_levels.sqlite`

## Telegram Setup (Required)
1. Create a bot using **BotFather** and copy the bot token.
2. Add the bot as **Admin** to your Telegram channel and allow posting.
3. Get your channel `chat_id`:
   - Send a message in the channel (any text).
   - Open this URL in your browser (replace `<BOT_TOKEN>`):
     `https://api.telegram.org/bot<BOT_TOKEN>/getUpdates`
   - Find the latest message and read `chat.id` (starts with `-100...`).
4. Add `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` to Replit Secrets.
5. In Admin, click **Test Telegram** to confirm posting works.

## Admin Workflow
1. Go to `/admin` and log in.
2. Enter levels and setups for the day.
3. Choose **Tier** (Free or Pro).
4. Click **Save Draft** to save and preview.
5. Click **Publish FREE** or **Publish PRO** to send the message.
6. Use the **Copy** buttons for Free or Pro Substack versions.
6. Visit **Archive** to review history and logs.

## 10-Minute Test Checklist
1. App boots locally and `/health` returns `{"status":"ok"}`.
2. `/admin/login` loads and accepts `ADMIN_PASSWORD`.
3. Save a draft plan and confirm it persists.
4. Preview Telegram + Substack outputs render correctly.
5. Test Telegram message posts successfully.
6. Publish a plan and confirm status updates to `published`.
7. Verify archive list shows the new plan with published timestamp.
8. Open archive detail and confirm:
   - Saved levels match inputs
   - Telegram message is stored with variant label
   - Substack versions are copyable
   - Publish logs show success with variant
9. Try a publish with missing required fields and confirm it blocks.
10. Try a publish with invalid DZ (top <= bottom) and confirm it blocks.

## Troubleshooting
- **Login error**: verify `ADMIN_PASSWORD` is set in Replit Secrets.
- **Sessions not sticking**: set `SESSION_SECRET` in Replit Secrets.
- **Telegram 401/403**: check bot token and make sure bot is Admin in channel.
- **No chat_id**: confirm you’re using the channel `chat.id` from `getUpdates`.
- **Publish failed**: check logs in the archive detail page.
